// Smoke test: node tests/smoke.js   (ต้องมี playwright ติดตั้งไว้: npm i -D playwright)
// ตรวจว่าแอปเปิดได้ ไม่มี JS error, ตัวแก้เครื่องมือ (patchTool) หา anchor เจอครบ และคิวทบทวนจำกัดคำใหม่
const path = require('path');
const { chromium } = require('playwright');
const fail = [];
const check = (name, ok, extra = '') => { console.log((ok ? 'PASS ' : 'FAIL ') + name + (extra ? ' — ' + extra : '')); if (!ok) fail.push(name); };
(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 390, height: 800 }, serviceWorkers: 'block' });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push(e.message));
  await page.goto('file://' + path.resolve(__dirname, '..', 'index.html'));
  await page.waitForTimeout(1200);
  check('โหลดคำศัพท์ครบ', (await page.evaluate(() => S.words.length)) >= 4900);
  check('patchTool ไม่มี anchor ที่หาย', (await page.evaluate(() => window.__pgPatchFailures.length)) === 0,
        JSON.stringify(await page.evaluate(() => window.__pgPatchFailures)));
  check('worksheet-extras โหลดแล้ว', await page.evaluate(() => typeof PG_WS_HALF1 === 'function' && typeof pgEmojiFor === 'function' && typeof PG_WS_HALF2 === 'function'));
  const due = await page.evaluate(() => pgDueWords().length);
  check('โหลด vocab-tools / study-extras แล้ว', await page.evaluate(() => !!window.PGVocabTools && !!window.PGStudyExtras));
  check('คิวทบทวนวันแรกไม่เกิน 20 คำใหม่', due > 0 && due <= 20, String(due));
  for (const v of ['overview', 'vocab', 'review', 'cards', 'quiz', 'practice', 'handwriting', 'balloons', 'packs', 'dictionary', 'stats', 'fill', 'quality', 'leeches']) {
    await page.evaluate(v => { location.hash = v; }, v);
    await page.waitForTimeout(400);
  }
  check('ไม่มี JS error ตลอดการเปิดทุกหน้า', errors.length === 0, errors.join(' | '));
  await browser.close();
  process.exit(fail.length ? 1 : 0);
})();
