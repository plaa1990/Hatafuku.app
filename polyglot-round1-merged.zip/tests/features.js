// Feature test (round 1): node tests/features.js   (ต้องมี playwright)
// ตรวจฟีเจอร์ข้อ 1–5, 8, 9: เติมข้อมูล, แก้หลายรายการ, ตรวจคุณภาพ, คำอ่านจาก JMdict, leech, คีย์ลัด, คำประจำวัน
const path = require('path');
const { chromium } = require('playwright');
const ROOT = process.argv[2] || path.resolve(__dirname, '..');
const fail = [];
const check = (name, ok, extra='') => { console.log((ok?'PASS ':'FAIL ')+name+(extra?' — '+extra:'')); if(!ok) fail.push(name); };
(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport:{width:1200,height:900}, serviceWorkers:'block' });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push(e.message));
  page.on('dialog', d => d.accept());
  await page.goto('file://'+path.join(ROOT,'index.html'));
  await page.waitForTimeout(1200);
  const go = async v => { await page.evaluate(v => { location.hash = v; }, v); await page.waitForTimeout(300); };
  check('words loaded', (await page.evaluate(()=>S.words.length))>=4900);
  check('patch failures none', (await page.evaluate(()=>window.__pgPatchFailures.length))===0);

  // ---- item 9: word of the day
  await go('overview');
  check('wotd renders', await page.locator('#wotd').count()===1);
  const w1 = await page.evaluate(()=>S.wotd.id);
  await page.reload(); await page.waitForTimeout(800);
  check('wotd stable through reload', (await page.evaluate(()=>S.wotd.id))===w1);
  check('wotd is a new word', await page.evaluate(()=>PG.isNewWord(S.words.find(w=>w.id===S.wotd.id))));
  await page.click('#wotd-next'); await page.waitForTimeout(200);
  const w2 = await page.evaluate(()=>S.wotd.id);
  check('wotd re-roll changes', w2!==w1);
  const dueBefore = await page.evaluate(()=>pgDueWords().length);
  await page.click('#wotd-add'); await page.waitForTimeout(200);
  check('wotd add enters queue', await page.evaluate(id=>pgDueWords().some(w=>w.id===id), w2));
  check('wotd add button disabled after', await page.locator('#wotd-add').isDisabled());

  // ---- item 1: fill view form mode
  await go('fill');
  check('fill setup rendered', await page.locator('#fill-start').count()===1);
  const cnt = await page.locator('#fill-count').textContent();
  check('fill default count = 248 (th|en empty)', /248/.test(cnt), cnt);
  await page.click('#fill-start'); await page.waitForTimeout(200);
  check('fill form shown', await page.locator('#fill-form').count()===1);
  const firstId = await page.evaluate(()=>PGVocabTools.fillState.queue[0]);
  await page.evaluate(()=>{ const f=document.querySelector('#ff-th'); });
  const emptyTh = await page.evaluate(id=>!S.words.find(w=>w.id===id).th.trim(), firstId);
  const fieldToFill = emptyTh ? '#ff-th' : '#ff-en';
  await page.fill(fieldToFill, 'ทดสอบ-fill');
  await page.locator('input[name=level][value=B1]').check({force:true});
  await page.press(fieldToFill, 'Enter'); await page.waitForTimeout(200);
  const saved = await page.evaluate(id=>{const w=S.words.find(w=>w.id===id);return {th:w.th,en:w.en,level:w.level,pos:PGVocabTools.fillState.pos}}, firstId);
  check('fill saved + advanced', (saved.th==='ทดสอบ-fill'||saved.en==='ทดสอบ-fill') && saved.level==='B1' && saved.pos===1, JSON.stringify(saved));
  const persisted = await page.evaluate(id=>JSON.parse(localStorage.getItem('pg:v1')).words.find(w=>w.id===id).level, firstId);
  check('fill persisted to localStorage', persisted==='B1');
  await page.click('#fill-skip'); await page.click('#fill-back'); await page.waitForTimeout(100);
  check('skip/back navigates', (await page.evaluate(()=>PGVocabTools.fillState.pos))===1);
  // quick level mode
  await page.click('#fill-quit');
  await page.selectOption('#fill-mode','level'); await page.waitForTimeout(100);
  const levelCount = await page.locator('#fill-count').textContent();
  check('level mode count', /4,?9\d\d|4,?937/.test(levelCount)||/\d/.test(levelCount), levelCount);
  await page.click('#fill-start'); await page.waitForTimeout(200);
  const q0 = await page.evaluate(()=>PGVocabTools.fillState.queue[0]);
  await page.keyboard.press('3'); await page.waitForTimeout(100);
  check('quick level key 3 -> B1', await page.evaluate(id=>S.words.find(w=>w.id===id).level, q0)==='B1');
  await page.keyboard.press('6'); await page.keyboard.press('Space'); await page.keyboard.press('ArrowLeft'); await page.waitForTimeout(500);
  const pos = await page.evaluate(()=>PGVocabTools.fillState.pos);
  check('quick level key nav', pos===2, String(pos));
  const q1 = await page.evaluate(()=>PGVocabTools.fillState.queue[1]);
  check('quick level 6 -> C2', await page.evaluate(id=>S.words.find(w=>w.id===id).level, q1)==='C2');
  await page.waitForTimeout(500);
  check('quick level persisted after debounce', await page.evaluate(id=>JSON.parse(localStorage.getItem('pg:v1')).words.find(w=>w.id===id).level, q0)==='B1');

  // ---- item 2: bulk edit
  await go('vocab');
  check('bulk bar present', await page.locator('#bulk-bar').count()===1);
  check('row checkboxes present', (await page.locator('#vlist .bulk-cb').count())>=100);
  await page.locator('#vlist .bulk-cb').nth(0).check(); await page.locator('#vlist .bulk-cb').nth(1).check();
  check('bulk count 2', /2/.test(await page.locator('#bulk-count').textContent()));
  const ids2 = await page.evaluate(()=>[...PGVocabTools.bulkSel]);
  await page.selectOption('#bulk-level','C1'); await page.click('#bulk-level-go'); await page.waitForTimeout(200);
  check('bulk level applied', await page.evaluate(ids=>ids.every(id=>S.words.find(w=>w.id===id).level==='C1'), ids2));
  await page.fill('#bulk-cat','หมวดทดสอบ'); await page.click('#bulk-cat-go'); await page.waitForTimeout(200);
  check('bulk category applied', await page.evaluate(ids=>ids.every(id=>S.words.find(w=>w.id===id).category==='หมวดทดสอบ'), ids2));
  await page.fill('#bulk-tag','tagA, tagB'); await page.click('#bulk-tag-add'); await page.waitForTimeout(200);
  check('bulk tag added', await page.evaluate(ids=>ids.every(id=>{const t=S.words.find(w=>w.id===id).tags;return t.includes('tagA')&&t.includes('tagB')}), ids2));
  await page.fill('#bulk-tag','tagA'); await page.click('#bulk-tag-del'); await page.waitForTimeout(200);
  check('bulk tag removed', await page.evaluate(ids=>ids.every(id=>{const t=S.words.find(w=>w.id===id).tags;return !t.includes('tagA')&&t.includes('tagB')}), ids2));
  await page.selectOption('#bulk-status','mastered'); await page.click('#bulk-status-go'); await page.waitForTimeout(200);
  check('bulk status applied', await page.evaluate(ids=>ids.every(id=>S.words.find(w=>w.id===id).workStatus==='mastered'), ids2));
  const nBefore = await page.evaluate(()=>S.words.length);
  await page.click('#bulk-delete'); await page.waitForTimeout(300);
  check('bulk delete', (await page.evaluate(()=>S.words.length))===nBefore-2);
  await page.click('#bulk-undo'); await page.waitForTimeout(300);
  check('undo restores deleted', (await page.evaluate(()=>S.words.length))===nBefore && await page.evaluate(ids=>ids.every(id=>S.words.some(w=>w.id===id)), ids2));
  // filter-select-all
  await page.fill('#vs','Hello'); await page.waitForTimeout(300);
  await page.click('#bulk-filtered'); await page.waitForTimeout(200);
  const filteredN = await page.evaluate(()=>PGVocabTools.filteredWords().length);
  check('select all filtered matches count', (await page.evaluate(()=>PGVocabTools.bulkSel.size))===filteredN && filteredN>0, String(filteredN));
  await page.click('#bulk-clear');

  // ---- item 3: quality
  await go('quality');
  check('quality view', await page.locator('[data-qtab]').count()===4);
  const groups = await page.evaluate(()=>PGVocabTools.dupGroups('strict').length);
  check('strict dup groups found', groups>=10, String(groups));
  const nWords = await page.evaluate(()=>S.words.length);
  const extra = await page.evaluate(()=>PGVocabTools.dupGroups('strict').reduce((n,g)=>n+g.words.length-1,0));
  await page.click('[data-merge="0"]'); await page.waitForTimeout(300);
  check('merge one group', (await page.evaluate(()=>S.words.length))<nWords);
  await page.click('#q-undo'); await page.waitForTimeout(300);
  check('undo merge', (await page.evaluate(()=>S.words.length))===nWords);
  await page.click('#dup-merge-all'); await page.waitForTimeout(400);
  check('merge all strict', (await page.evaluate(()=>S.words.length))===nWords-extra && (await page.evaluate(()=>PGVocabTools.dupGroups('strict').length))===0, String(extra));
  await page.selectOption('#dup-mode','th'); await page.waitForTimeout(200);
  check('th dup mode lists groups', (await page.locator('.dup-group').count())>0);
  await page.locator('[data-ignore="0"]').click(); await page.waitForTimeout(200);
  check('ignore group persists', (await page.evaluate(()=>S.dupIgnore.length))===1);
  await page.click('[data-qtab="cat"]'); await page.waitForTimeout(200);
  check('cat tab lists', (await page.locator('[data-cat-id]').count())>0);
  await page.locator('[data-cat-id]').nth(0).check(); await page.locator('[data-cat-id]').nth(1).check();
  const catIds = await page.evaluate(()=>[...PGVocabTools.qState.catSel]);
  await page.fill('#cat-name','จัดแล้ว'); await page.click('#cat-go'); await page.waitForTimeout(300);
  check('cat tab applies', await page.evaluate(ids=>ids.every(id=>S.words.find(w=>w.id===id).category==='จัดแล้ว'), catIds));
  await page.click('[data-qtab="gaps"]'); await page.waitForTimeout(200);
  check('gaps tab stats', (await page.locator('.stat-card').count())===5);
  check('gaps list', (await page.locator('.leech-row').count())>0);

  // ---- item 4: kana suggestions with a fake JMdict
  await page.evaluate(async () => {
    const jp = S.words.filter(w=>/[一-鿿]/.test(w.jp||'') && (w.jp||'').length<=3 && !w.jpKana).slice(0,5);
    window.__kanaIds = jp.map(w=>w.id);
    const entries = jp.map((w,i)=>({id:'t'+i,headword:w.jp,reading:'てすと'+i,forms:[w.jp],readings:i===0?['てすと0','べつ0']:['てすと'+i],meanings:[i===1?(w.en||'x'):'nomatch'+i],source:'JMdict'}));
    await new Promise((res,rej)=>{const r=indexedDB.open('polyglot-offline-dictionary',1);r.onupgradeneeded=()=>{if(!r.result.objectStoreNames.contains('entries'))r.result.createObjectStore('entries',{keyPath:'id'})};r.onsuccess=()=>{const tx=r.result.transaction('entries','readwrite');const st=tx.objectStore('entries');entries.forEach(e=>st.put(e));tx.oncomplete=()=>{r.result.close();res()};tx.onerror=()=>rej(tx.error)};r.onerror=()=>rej(r.error)});
  });
  await page.reload(); await page.waitForTimeout(800);
  await go('quality'); await page.click('[data-qtab="kana"]'); await page.waitForTimeout(800);
  const rows = await page.locator('.kana-row').count();
  check('kana suggestions listed', rows>=1, String(rows));
  const before = await page.evaluate(()=>S.words.filter(w=>w.jpKana).length);
  const before0 = before; check('kana never auto-applied (suggestions listed, nothing written)', before>0 && before===(await page.evaluate(()=>S.words.filter(w=>w.jpKana).length)), String(before));
  await page.click('#kana-apply'); await page.waitForTimeout(200);
  check('apply with nothing ticked does nothing', (await page.evaluate(()=>S.words.filter(w=>w.jpKana).length))===before);
  await page.locator('[data-kana="1"]').check();
  await page.click('#kana-apply'); await page.waitForTimeout(400);
  check('kana applied only for ticked row', (await page.evaluate(()=>S.words.filter(w=>w.jpKana).length))>=before+1);
  const ids = await page.evaluate(()=>window.__kanaIds||[]);

  // ---- item 5: leech
  await page.evaluate(()=>{ const ws=S.words.slice(10,13); ws[0].lapses=4; ws[1].quizWrong=3; ws[2].lapses=1; ws[2].quizWrong=2; save(); });
  await go('leeches');
  const leechN = await page.locator('[data-leech]').count();
  check('leech list shows 3', leechN===3, String(leechN));
  await page.click('#leech-tag'); await page.waitForTimeout(200);
  check('leech tag applied', (await page.evaluate(()=>S.words.filter(w=>w.tags.includes('leech')).length))===3);
  await page.click('#leech-drill'); await page.waitForTimeout(200);
  await page.keyboard.press('Space'); await page.waitForTimeout(100);
  check('drill reveal via space', await page.locator('[data-q]').count()===4);
  const lap0 = await page.evaluate(()=>S.words[10].lapses);
  await page.keyboard.press('1'); await page.waitForTimeout(100);
  check('drill rating via key advances', (await page.evaluate(()=>PGVocabTools.leechState.drill.pos))===1);
  await page.click('#drill-exit'); await page.waitForTimeout(100);
  await page.locator('[data-reset]').first().click(); await page.waitForTimeout(200);

  // ---- item 8: review shortcuts
  await go('review'); await page.waitForTimeout(300);
  check('review shows keyhint', await page.locator('.study-keyhint').count()===1);
  await page.keyboard.press('Space'); await page.waitForTimeout(100);
  check('space reveals answer', await page.locator('[data-quality]').count()===4);
  const dueN = await page.evaluate(()=>pgDueWords().length);
  const hist = await page.evaluate(()=>Object.values(S.studyLog).reduce((a,b)=>a+b,0));
  await page.keyboard.press('3'); await page.waitForTimeout(150);
  check('key 3 rated "good"', (await page.evaluate(()=>Object.values(S.studyLog).reduce((a,b)=>a+b,0)))===hist+1);
  await page.keyboard.press('2'); await page.waitForTimeout(100);
  check('rating key ignored when answer hidden', (await page.evaluate(()=>Object.values(S.studyLog).reduce((a,b)=>a+b,0)))===hist+1);
  await page.keyboard.press('Space'); await page.keyboard.press('1'); await page.waitForTimeout(150);
  check('key 1 rated again', (await page.evaluate(()=>Object.values(S.studyLog).reduce((a,b)=>a+b,0)))===hist+2);
  // typing in an input must not trigger shortcuts
  await page.focus('#review-new-limit'); const h2 = await page.evaluate(()=>Object.values(S.studyLog).reduce((a,b)=>a+b,0));
  await page.keyboard.press('Space'); await page.keyboard.press('1');
  check('shortcuts ignored while select focused', (await page.evaluate(()=>Object.values(S.studyLog).reduce((a,b)=>a+b,0)))===h2);

  for (const v of ['overview','vocab','review','cards','quiz','practice','handwriting','balloons','packs','dictionary','stats','fill','quality','leeches']) { await go(v); }
  check('nav lists new routes', (await page.locator('#nav a[href="#fill"], #nav a[href="#quality"], #nav a[href="#leeches"]').count())===3);
  check('no JS errors', errors.length===0, errors.join(' | '));
  await browser.close();
  console.log(fail.length? 'FAILED: '+fail.join(', ') : 'ALL PASSED');
  process.exit(fail.length?1:0);
})().catch(e=>{console.error(e);process.exit(2)});
